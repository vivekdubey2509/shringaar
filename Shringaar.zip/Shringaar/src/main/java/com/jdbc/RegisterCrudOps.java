package com.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegisterCrudOps {
	public void insertInfo(String name, String age, String city, String state, String phonenumber, String email, String password) {
		Connect c = new Connect();
		Connection con = null;
		PreparedStatement ps = null;

		con = c.getConnection();
		try {
			ps = con.prepareStatement("insert into registereduser(name,age,city,state,phonenumber,email,password) values (?,?,?,?,?,?,?)");
			
			ps.setString(1, name);
			ps.setString(2, age);
			ps.setString(3, city);
			ps.setString(4, state);
			ps.setString(5, phonenumber);
			ps.setString(6, email);		
			ps.setString(7, password);
			
			ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
