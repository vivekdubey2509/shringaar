package com.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ChatCrudOps {
	

	public void insertChat( String email, String msg) {
		Connect c = new Connect();
		Connection con = null;
		PreparedStatement ps = null;

		con = c.getConnection();
		try {
			ps = con.prepareStatement("insert into chat(email,msg) values (?,?)");
			
		
			ps.setString(1, email);
			ps.setString(2, msg);

			
			ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
